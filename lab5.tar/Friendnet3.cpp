#include <iostream>
#include <vector>
#include <set>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <algorithm>
#include <string>
#include <stdlib.h>

// Dillon Frankenstein
// Lab 5 - version 2
// Creates a friend network

using namespace std;

class vtable {
  public:
    int size() { return v.size(); }  // returns name vector size
    void push(string &push_val) { v.push_back(push_val); } // pushes the names onto the vector
    string operator[](int &i) { return v[i]; } // returns the name

	vector<string>::iterator begin() { return v.begin(); } // begin iterator
	vector<string>::iterator end() { return v.end(); } // end iterator

  private:
    vector<string> v; // name vector
};

class adjtable {
  public:
    int size() { return E.size(); } // returns edge row size

    void set_size(int &); // sets the row and columns size
    std::set<int> & operator[](int &i) { return E[i]; } // returns a reference to the row and the column
	

  private:
    vector <set<int> > E; // Edge Matrix
};

void adjtable::set_size(int &i) { // sets the size of the edge vector
	E.resize(i);
}

void set_oldfriends(vtable &names, adjtable &friends, int M0, int M1) {
	int N = (int)names.size();
	friends.set_size(N);

    // declares do_know to indices in the amount of names passed
	vector<int> do_know(N);
	for (unsigned int i = 0; i < do_know.size(); i++) {
		do_know[i] = i;
	}

	for (int i=0; i<N; i++) {
		int M = M0 + rand () % (M1 - M0 +1); // random number being generated
		

		for (int d = 0; d < M; d++) { // do_know vector being swapped M times
			swap (do_know[d], do_know[rand() % (N)]);
		}
			// linking friends
		int j = do_know[i];
		if (i != j) {
			friends[i].insert(j);
			friends[j].insert(i);		
		}
	}
	
}

void set_newfriends(adjtable &friends, adjtable &new_friends) {
	
	// variables and iterators used
	int N = (int)friends.size();
	set<int>::iterator l0;
	set<int>::iterator l1;
	set<int>::iterator k0;
	set<int>::iterator k1;
	new_friends.set_size(N);
	int j, k;

	for (int i = 0; i < N; i++) { // for every name
		l0 = friends[i].begin();
		l1 = friends[i].end();
			while (l0 != l1) { // friend of name
				j = *l0;
				k0 = friends[j].begin();
				k1 = friends[j].end();
				while (k0 != k1) { // friend of friend
					k = *k0;
					if (i != k) { // making sure the friend is not the original name
						new_friends[i].insert(k); 
						new_friends[k].insert(i); 
					}
					k0++;
				}
				l0++;
			}
		}	 
}

void writetofile(const char *fname, vtable &name, adjtable &friends) {
	int N = (int)name.size();
	unsigned int max_name_l = 0;
	int j;

	// determines max name length 
	for (int i = 0; i < N; i++) {
		if (name[i].length() > max_name_l) {
			max_name_l = name[i].length();
		}
	}

	// opens output stream - should be no need for error checking
	ofstream out;
	out.open(fname);

	// prints name[i] and name[j]
	set<int>::iterator k0;
	set<int>::iterator k1;

	// formatted output using some iterators
	for (int i = 0; i < N; i++) {
		k0 = friends[i].begin();
		k1 = friends[i].end();
		out << setw(max_name_l) << left << name[i] << " : ";
		while (k0 != k1) {
			j = *k0;
			if (i != j) {
			out << setw(max_name_l) << name[j] << "	"; }
			k0++;
		}
		out << '\n';
	}
	out.close();
}

 /* I uses this function to test if the input was added and sorted correctly
template <typename T>
void print(T p0, T p1) {
	cout << "hello";
	while (p0 != p1) {
		cout << "cool";
		cout << "names: " << *p0 << '\n';
		p0++;
	}
} */

int main(int argc, char *argv[]) {
	int seed = 0; // default seed value
	int M0 = 1;   // min number of friends
	int M1 = 2;   // max number of friends
	string fname; // passes file name
	bool option_error;

	// usage
	if (argc == 1) { cout << "usage: [-seed=N] [-M0=N] [-M1=N]\n"; exit(0); }
	
	// command line parsing
	if (argc == 4 || argc ==  5) {
		for (int i = 1; i < argc; i++) {
			string option = argv[i];
			if (option.compare(0, 6, "-seed=") == 0) { 
				seed = atoi(&argv[i][6]); 
			} else if (option.compare(0, 4, "-M0=") == 0) { 
				M0 = atoi(&argv[i][4]); 
			} else if (option.compare(0, 4, "-M1=") == 0) { 
				M1 = atoi(&argv[i][4]); 
			} else if (option.compare(6, 8, "txt") == 0) {
				fname = argv[i];
			} else {
				option_error = true;
				break;
			}
		}
	}

	//  specific option errors
	if (option_error) { cout << "not valid option entered"; exit(0); }
	if (M0 < 1) { cout << "M0 has to be over 0\n";  exit(0); }
	if (M0 > M1) { cout << "M0 cannot be bigger than M1\n";  exit(0); }
	if (M0 > 6 || M1 > 6) { cout << "M0 or M1 cannot be larger than 5\n"; exit(0); }

	srand(seed);

	ifstream in;
	in.open(fname);
	if (!in) { cout << "not a valid file or file not in directory"; exit(0); }
 
	vtable name; // vertex labels
	string n;
	while (in >> n) {  
		name.push(n);
	}

	sort(name.begin(), name.end());

	adjtable friends;
	adjtable new_friends;

	set_oldfriends(name, friends, M0, M1);
	writetofile("doknow1.txt", name, friends);

	set_newfriends(friends, new_friends);
	writetofile("mightknow1.txt", name, new_friends);
  
	return 0;
}
