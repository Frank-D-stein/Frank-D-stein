// Dillon Frankenstein
// 10/20/2022 - 11/05/2022 
// Lab 6 Vers 3

#include <math.h>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <queue>
#include <stack>
#include <string>
#include <vector>
#include <climits>
#include <stdio.h>
#include <utility>

using namespace std;

#define DEG2RAD (M_PI/180.0)
#define RAD2DEG (180.0/M_PI)

enum city_t { LOCAL, METRO, REGIONAL, NATIONAL };

// Global city type vector
vector <string> city_type {"LOCAL", "METRO", "REGIONAL", "NATIONAL" }; 

class city {
	public:
		string get_name() { return name; } // Get functions
		city_t get_type() { return type; }
		float get_latitude() { return latitude; }
		float get_longitude() { return longitude; }
		int get_population() { return population; }
		
		void set_name (string & temp_name) { name = temp_name; } // set funtions
		void set_type (int i) { type = city_t(i); } 
		void set_latitude(float & temp_latitude) { latitude = temp_latitude; }
		void set_longitude(float & temp_longitude) { longitude = temp_longitude; }
		void set_population(int & temp_population) { population = temp_population; }
		
		// remove function comparison
		friend bool operator==(const city &a, const city &b)
			{ return a.population == b.population; } 
		// sort function comparison
		bool const operator<(const city &c) 
			{ return population < c.population; }					  
		// width variable
		static int w; 

	private:
		string name;
		city_t type;
		float latitude, longitude;
		int population;
};

int city::w = 1;

istream & operator>>(istream &in, city &c) { 
	
	string name, state, type; 
	float latitude, longitude;
	int population;
	
	// reading in name and state, combining them, and the setting the name var
	in >> name; 
	if (name.length() == 0) { return in; }
	in >> state;
	name = name + "_" + state;
	c.set_name(name);

	// calculates the longest name using the width var
	if ((int)name.length() > city::w) { city::w = name.length() + 5; } 
	
	// type caluculation through comparing to the global string type vector
	in >> type;
	for (unsigned int i = 0; i < city_type.size(); i++) { 
		if (type == city_type[i]) { c.set_type(i); }
	} 

	// latitude input
	in >> latitude; 
	c.set_latitude(latitude);
	
	// longitude input
	in >> longitude; 
	c.set_longitude(longitude);
	
	// population input
	in >> population; 
	c.set_population(population);
	
	return in;
}

ostream & operator<<(ostream &out, city &c) { // output operator
	
	out << left << setw(city::w) << setfill('.') << c.get_name() 
		<< setfill(' ') << "  " << setw(8) << right 
		<< c.get_population();
	
	return out;
}

void read_cityinfo(string &fname, vector<city> &v) { // reads data in
	// variables needed for reasing in data
	ifstream in; 
	in.open(fname);
	city r_city;
	string skip;

	// error checking and skipping the first line
	if (!in) { cout << "Invalid file passed (Input)\n"; exit(0); } 
	getline(in, skip);
	
	// input loop and city vector push 
	while (in.good()) { 
		in >> r_city;	
		v.push_back(r_city); 
	}

	// sorting in decreasing order and deleting duplicates
	sort(v.begin(), v.end()); 
	v.erase(unique(v.begin(), v.end()), v.end());
	reverse(v.begin(), v.end());

	in.close();
}

void write_cityinfo(const char *fname, vector<city> &v) { // write data out
	// output stream
	ofstream out; 
	out.open(fname);

	// error checking
	if (!out) { cout << "Invalid file passed (Output)\n"; exit(0); } 

	// output loop
	for (unsigned int i = 0; i < v.size(); i++) { 
		out << " " << setw(3) << right << i << "  " << v[i] << '\n';
	}
	
	out.close();
}

// class used by time_table and dist_table
class smatrix {
	public:
		void set_size(int);
		float get_value(int i, int j) { return matrix[i][j]; }
		void set_value(int i, int j, float val) { matrix[i][j] = val; }

	private:
		vector< vector<float> > matrix; // 2D Matrix 

};

// creates a NxN matrix
void smatrix::set_size(int N) {
	matrix.resize(N);
	for (unsigned int i = 0; i < matrix.size(); i++) {
		matrix[i].resize(N);
	}
}

// creates the distance table
void create_citydist(smatrix &dist_table, vector<city> &v) {
	//  haversine equation variables
	float r = 3982.0, d, lat1, lat2, lon1, lon2; 
	dist_table.set_size((int)v.size());

	// 2D loop to compare every pair of names
	for (unsigned int i = 0; i < v.size(); i++) { 
		for (unsigned int j = 0; j < v.size() && j <= i; j++) {
			
			lat1 = v[i].get_latitude() * DEG2RAD;
			lat2 = v[j].get_latitude() * DEG2RAD;
			lon1 = v[i].get_longitude() * DEG2RAD;
			lon2 = v[j].get_longitude() * DEG2RAD;
			
			// Haversine Function
			d = 2*r*asin(sqrt(pow (sin(((lat2 - lat1)/2)), 2) +
				cos(lat1) * cos(lat2) * pow (sin((lon2 - lon1)/2), 2)));
			
			// rouding 
			d = 5.0*round(d/5.0);	

			// setting
			dist_table.set_value(i, j, d);
			dist_table.set_value(j, i, d);
		}
	}
}

float plane_speed = 500; // [mph]
float truck_speed = 55;  // [mph]

// creates the time table
void create_citytime(smatrix &time_table, vector<city> &v, smatrix &dist_table) {
	time_table.set_size((int)v.size());

	// 2D loop comparing every pair of names
	for (unsigned int i = 0; i < v.size(); i++) {
		for (unsigned int j = 0; j < v.size(); j++) {
			
			// if both cities are of type National
			if (v[i].get_type() == 3 && v[j].get_type() == 3) {

				time_table.set_value(i, j, (dist_table.get_value(i, j) 
							/ plane_speed));	
				time_table.set_value(j, i, (dist_table.get_value(i, j) 
							/ plane_speed));

			// if one or both are type non-National	
			} else {

				time_table.set_value(i, j, (dist_table.get_value(i, j) 
							/ truck_speed));
				time_table.set_value(j, i, (dist_table.get_value(i, j) 
							/ truck_speed));
			}
		}
	}
}

// write the city distance
void write_citydist(const char *fname, smatrix &dist_table, vector<city> &v) { 
	// output stream
	ofstream out (fname); 
	if (!out) { cout << "Invalid File passed\n"; exit(0); }

	// 2D loop going through every name pair
	for (unsigned int i = 0; i < v.size(); i++) { 
		for (unsigned int j = 0; j < v.size() && j < i; j++) {

			out << right << " " << setw(3) << i << "  " << left 
				<< setw(city::w) << setfill('.') << v[i].get_name() 
				<< setfill(' ') << " to " << setfill('.') << setw(city::w) 
				<< v[j].get_name() << setfill(' ') << "  " << right << setw(6) 
				<< fixed << setprecision(1) << dist_table.get_value(i, j)  
				<< " " << "miles\n";
		}
		if (i != 0) out << '\n';
	}
}

void write_citytime(const char *fname, smatrix &time_table, vector <city> &v) {
	// output stream
	ofstream out (fname);
	if (!out) { cout << " Invalid File passed\n"; exit(0); } 

	// 2D loop comparing every pair of names which time != 0
	for (unsigned int i = 0; i < v.size(); i++) {
		for (int j = 0; time_table.get_value(i, j) != 0; j++) {

			out << right << " " << setw(3) << i << "  " << left 
				<< setw(city::w) << setfill('.') << v[i].get_name() 
				<< setfill(' ') << " to " << setfill('.') << setw(city::w) 
				<< v[j].get_name() << setfill(' ') << "   " << setw(5) 
				<< right << fixed << setprecision(1) << time_table.get_value(i, j) 
				<< " hours\n";
		}
		if (i != 0) { out << '\n'; }
	}
}

int national_minpop = 2000000;
int regional_minpop =  500000;
 
float national_dist = 200.0;
float regional_dist = 100.0;
float local_dist = 75.0;

bool sortbysec(const pair<int, float> &a, const pair<int, float> &b) 
	{ return a.second < b.second; }

bool func (pair<int, float> &yep) 
	{ return (yep.second < 10); }

void create_citygraph(vector<city> &v, vector < vector<int> > &adjtable, smatrix &dist_table) {

	vector <int> national;	// all national city indeces
	vector <int> regional;  // all regional city indeces
	vector <vector <pair<int,float>> > city_pair; // all non local city indecs

	// Setting the correct type and adding them to the corresponding vector
	for (unsigned int i = 0; i < v.size(); i++) { 
		// if the city is of type METRO 
		if (city_type[v[i].get_type()] == "METRO") {	
			
			// if the population is greater than the min nat pop, set national
			if (v[i].get_population() > national_minpop) { 
				v[i].set_type(3);
			} 

			// if the population is greater than mim reg pop, set regional
			if (v[i].get_population() > regional_minpop 
				&& v[i].get_population() < national_minpop) { 
				v[i].set_type(2);
			}

			// if the population is less than min reg pop, set local
			if (v[i].get_population() < regional_minpop) { 
				v[i].set_type(0); 
			}
		}
	// pushing national and regional cities to their respective vector	
	if (v[i].get_type() == 3) { national.push_back(i); } 
	if (v[i].get_type() == 2) { regional.push_back(i); } 
	}
	// largest national city population variable
	int national_largest = 0;
	// distance between national cities variable
	float distance1;	 

	// compares every national city
	for (unsigned int i = 0; i < national.size(); i++) {  
		for (unsigned int j = 0; j < national.size(); j++) {
			
			// distance between pairs
			distance1 = dist_table.get_value(national[i], national[j]);
			
			// if the current city[j] is the biggest and within the nat dist
			if (v[national[j]].get_population() > national_largest 
				&& distance1 < national_dist) { 
				national_largest = v[national[j]].get_population();		
			}
		}

		// if the city[i] is not the biggest -> downgrade -> push to regional vector
		if (v[national[i]].get_population() < national_largest) { 
			v[national[i]].set_type(2);							
			regional.push_back(national[i]);							
		}
		// value reset
		national_largest = 0;
	}

	// largest regional city population variable
	int regional_largest = 0;					
	// distance between regional city variable
	float distance2;									  

	// compares every regional city
	for (unsigned int i = 0; i < regional.size(); i++) { 
		for (unsigned int j = 0; j < regional.size(); j++) {

			// distance between pairs
			distance2 = dist_table.get_value(regional[i], regional[j]); 

			// if the current city[j]  is the biggest and within the reg dist
			if (v[regional[j]].get_population() > regional_largest 
				&& distance2 < regional_dist && v[regional[j]].get_type() == 2) { 
					regional_largest = v[regional[j]].get_population();
			}

		}
		// if the city[i] is not the biggest -> downgrade
		if (v[regional[i]].get_population() < regional_largest) { 
			v[regional[i]].set_type(0);
		}
		// value reset
		regional_largest = 0; 
	}

	// city_pair and adjtable resize 2D loop
	city_pair.resize((int)v.size());
	adjtable.resize((int)v.size());
	for (unsigned int k = 0;k < v.size(); k++) {
		city_pair[k].resize((int)v.size());
		adjtable[k].resize((int)v.size());
	}

	unsigned int k = 0;
	// adds all the national and regional cities to the city_pair vector
	for (unsigned int i = 0; i < v.size(); i++) {
		for (int j = 0; j < (int)national.size() && (int)i != national[j]; j++) { 
			// adds indeces and distances of that index to the current city
			city_pair[i][j].first = national[j];
			city_pair[i][j].second = dist_table.get_value(i, national[j]);
		}
		for (int j = national.size(); 
			j < (int)(regional.size() + national.size()); j++) { 
			// adds index and distances of that index to the current city
			city_pair[i][j].first = regional[k];
			city_pair[i][j].second = dist_table.get_value(i, regional[k]);
			k++;
		}
		k = 0;
		for (unsigned int l = 0;l < city_pair[i].size(); l++) {
			// removes cities if the distance is too small
			city_pair[i].erase(remove_if(city_pair[i].begin(), 
				city_pair[i].end(),func), city_pair[i].end());
		}
		
		// sorts all the cities by distance to the current city
		sort (city_pair[i].begin(), city_pair[i].end(), sortbysec);
		// erases duplicates
		city_pair[i].erase(unique(city_pair[i].begin(), 
					       city_pair[i].end()), city_pair[i].end());
	}
	
	// goes through the 2D matrix adjtable
	for (unsigned int i = 0; i < adjtable.size(); i++) {
		// if the current city is of type National
		if (city_type[v[i].get_type()] == "NATIONAL") { 
			for (unsigned int j = 0; j < adjtable[i].size(); j++) {
				if (city_type[v[j].get_type()] == "NATIONAL" && i != j) {
					// connects all national cities to each other
					adjtable[i][j] = 1;
					adjtable[j][i] = 1;
				}
			}
		}
	
		// if the current city is of type Regional
		if (city_type[v[i].get_type()] == "REGIONAL") {
			int j = 0;
			int g = 0;
			// connects to three non local cities
			while (g != 3) { 
				if ((int)i != city_pair[i][j].first && 
					city_type[v[city_pair[i][j].first].get_type()] != "LOCAL") {
						
						adjtable[i][city_pair[i][j].first] = 1;
						adjtable[city_pair[i][j].first][i] = 1;
						g++;
					}
					j++;
			}
		}

		// if the current city is of type Local
		if (city_type[v[i].get_type()] == "LOCAL") {
			int h = 0; 
			int j = 0;
			// connects to two non local cities
			while (h != 2) {
				// if the city is not being compared to itself and checks type
				if ((int)i != city_pair[i][j].first 
				&& city_type[v[city_pair[i][j].first].get_type()] != "LOCAL") {
					adjtable[i][city_pair[i][j].first] = 1;
					adjtable[city_pair[i][j].first][i] = 1;
					h++;
				}
				j++;
			}
			// connects all local cities in the local dist range
			for (unsigned int j = 0; j < v.size(); j++) {
				if (city_type[v[j].get_type()] == "LOCAL" 
					&& dist_table.get_value(i, j) <= local_dist && i != j) {
					adjtable[i][j] = 1;
					adjtable[j][i] = 1;
				}
			}
		}
	}
}

void write_citygraph(const char *fname, vector <vector<int> > &adjtable, 
	vector<city> &v, smatrix &time_table, smatrix &dist_table) {
	// output stream
	ofstream out (fname);
	if (!out) { cout << "Invalid File passed\n"; exit(0); } 

	// goes through the 2D ajdtable matrix
	for (unsigned int i = 0; i < adjtable.size(); i++) {
		out << " " << setw(3) << i << " " << v[i].get_name() << '\n';
		for (unsigned int j = 0; j < adjtable[i].size(); j++) {
			if (adjtable[i][j] == 1) {	
				out << 	"   " << setw(3) << right << j << " " << left 
					<< setfill('.') << setw(city::w) << v[j].get_name() 
					<< setfill(' ') << fixed << setprecision(1) << "  " 
					<< setw(6) << right << dist_table.get_value(i, j) << " miles" 
					<< setw(5) << time_table.get_value(i, j) << " hours\n";
			}
		}
		if (i != 0) { out << '\n'; }
	}
}

enum color_t { WHITE, BLACK };

void dijkstra_route(int source, int sink, string mode, vector< vector<int> > &adj, vector<city> &v, smatrix &table, smatrix &table1) {
	// color, distance, time, and lin vector
	vector<float> vtime;
	vector<color_t> vcolor;
	vector<float> vdist;
	vector<int> vlink;

	// assings
	vcolor.assign(v.size(), WHITE);
	vdist.assign(v.size(), numeric_limits<float>::max());
	vtime.assign(v.size(), numeric_limits<float>::max());
	vlink.assign(v.size(), -1);

	// needed to find the source
	vtime[source] = 0;
	vdist[source] = 0;
	vlink[source] = source;

	while (1) {
		int next_i = -1;
		float mindist = numeric_limits<float>::max();

		// if the passed mode is distance
		if (mode == "-dist") { 
			for (int i = 0; i <(int)vcolor.size(); i++) {
				// finds out where the source is
				if (vcolor[i] == WHITE && mindist > vdist[i]) {
				next_i = i;
				mindist = vdist[i];
				}
			}
		// if the passed mode is time	
		} else if (mode == "-time") {
			for (int i = 0; i <(int)vcolor.size(); i++) {
				// finds out where the source is
				if (vcolor[i] == WHITE && mindist > vtime[i]) {
					next_i = i;
					mindist = vtime[i];
				}
			}
		
		}

		// if the source was not in the name vector
		int i = next_i;
		if (i == -1)
			return;

		// sets the sources color to black
		vcolor[i] = BLACK;

		// if the source has reached the sink, the loop ends
		if (i == sink)
			break;

		// goes through all the connections of the i-th city
		for (int k = 0; k <(int)adj[i].size(); k++) {
			// if the two cities are connected
			if (adj[i][k] == 1) {
				int j = k;
				float wij = table.get_value(i, k);
				float wij2 = table1.get_value(i, k);

				if (vcolor[j] == BLACK)
					continue;
	
				// sets the link, time, and primarily the distance vector
				if (mode == "-dist") {
					if (vdist[j] > vdist[i] + wij) {
						vdist[j] = vdist[i] + wij;
						vtime[j] = vtime[i] + wij2;
						vlink[j] = i;
					}
				// sets the link, distance, and primarily the time vector
				} else if (mode == "-time") {
					if (vtime[j] > vtime[i] + wij) {
						vtime[j] = vtime[i] + wij;
						vdist[j] = vdist[i] + wij2;
						vlink[j] = i;
					}
				}
			}
		}
	}

	stack<int> S;

	// adds all indeces between sink and source to the stack S
	for (int i = sink; i != source; i = vlink[i])
		S.push(i);
	S.push(source);
	
	//  total time and distance variable needed
	float d_total, t_total;
	// while the stack S is not empty
	while (!S.empty()) {
		// first element in the Stack and removes it from the stack
		int i = S.top();
		S.pop();

		cout << setw(8) << right << fixed << setprecision(2) << vdist[i]
			 << " miles " << setw(5) << vtime[i] << " hours  "
			 << setw(3) << i << " " << v[i] << " ";
		if (i != source) {	
			cout << setw(7) << (vdist[i] - d_total) << " miles " 
				 << setw(5) << (vtime[i] - t_total) << " hours";
		}
		// sets the total to the past dist/time and 
		// subtracts that from the current one
		d_total = vdist[i];
		t_total = vtime[i];
		cout <<  '\n';
	}
}

enum rmde_t {UNKNOWN, INFOMODE, DISTMODE, TIMEMODE };

int main(int argc, char *argv[]) {
	// city vector and command line parsing variables
	string fname, mode, source, sink;
	bool error = false;
	int error_val = 0, sourcei, sinki;
	vector <city> vertex_table;
	
	// Command line parsing
	if (argc == 3) {
		for (int i = 1; i < argc; i++) {
			string option = argv[i];
			if (option.compare(0, 1, "-") == 0) {
				mode = argv[i];
			} else if (option.compare(9, 11, "txt") == 0) {
				fname = argv[i];
			} 
		}
	} else {
		cout << "usage: -info/-dist/-time cities.txt\n"; exit(0); }

	// matrix initialization
	read_cityinfo(fname, vertex_table);	
	smatrix dist_table;
	smatrix time_table;
	vector <vector<int>> city_adjtable;

	// creates the matrices
	create_citydist(dist_table, vertex_table);
	create_citygraph(vertex_table, city_adjtable, dist_table);
	create_citytime(time_table, vertex_table, dist_table);

	// writes the matrices
	write_citydist("city_dist.txt", dist_table, vertex_table);
	write_citygraph("city_graph.txt", city_adjtable, vertex_table, time_table, 
																	dist_table);
	write_citytime("city_time.txt", time_table, vertex_table);
	
	// if the mode if info the info of the vector is printed
	if (mode == "-info") {
		write_cityinfo("city_info.txt", vertex_table);
	// if the type is distance or time
	} else {
		while (cin) {
			// source and sink input
			cout << "Enter> ";
			cin >> source >> sink;
			// error check
			if (source == sink) { cout << "Cannot be the same city\n"; exit(0); }
			// checks if the passed strings are in the vector
			for (unsigned int i = 0; i < vertex_table.size(); i++) {
				if (source.compare(vertex_table[i].get_name()) == 0) {
					error_val++;
					sourcei = i;
				}
				if (sink.compare(vertex_table[i].get_name()) == 0) {
					error_val++;
					sinki = i;
				}
			}
			// if both strings are in the vector = error = true
			if (error_val == 2)   { error = true;
			} else {
				cout << "One or Both Cities are not in the vector\n";
			}	
			// calls the algorithm differently for each mode as the first
			// smatrix table that is passed will be the primary one
			if (error) { 
				if (mode == "-dist") {
					dijkstra_route(sourcei, sinki, mode, city_adjtable, vertex_table, dist_table, time_table); 
				} else {
					dijkstra_route(sourcei, sinki, mode, city_adjtable, vertex_table, time_table, dist_table);
				}
			}
			// var reset
			error = false;
			error_val = 0;
		}
	}
	return 0;
}
