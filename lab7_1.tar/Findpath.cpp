#include <stdlib.h>
#include <string.h>
#include <stdio.h>

// Dillon Frankenstein
// Lab 7
// 11/17/2022

// add constructor, operator overloads as needed
struct cell { 
	cell() { i = 0, j = 0; }
	cell(int, int);
	int i,j; 
	
};

cell::cell(int o, int p) { 
	i = o;
	j = p;
}

int main(int argc, char *argv[]) {
	char fname[20];
	char fname_out[80];
	
	// command line arguments
	if (argc == 3) {
		strcpy(fname, argv[1]); 
		strcpy(fname_out, argv[2]);
	} else {
		printf("usage: ./Findpath maze.txt path.txt\n");
		exit(0);
	}

	// obtain maze size from maze file header
	FILE * fp;
	char buff [80];
	int Nrows, Ncols;
	fp = fopen(fname, "r");
	if (!fp) {
		printf("File can't be read\n");
		exit(0);
	}

	fscanf(fp,"%s %i %i", buff, &Nrows, &Ncols);
		
	// initalizes the adjtable as a 3D bool array
	bool ***adjtable;
	adjtable = new bool**[Nrows]; // rows of double bool pointers
	for (int i = 0; i < Nrows; i++) {
		adjtable[i] = new bool*[Ncols];// columns of single bool pointers
		for (int j = 0; j < Ncols; j++) {
			adjtable[i][j] = new bool[4]; // 4 bool variables
			for (int k = 0; k < 4; k++) {
				adjtable[i][j][k] = false;
			}
		}
	}

	int i1, j1;
	
	// checks for valid edges between values
	for (int i = 0; i < Nrows; i++) {
		for (int j = 0; j < Ncols; j++) {
			fscanf(fp,"%i %i", &i1, &j1);
				if (i1 != Nrows) {
					adjtable[i1][j1][0] = true;
				} if (i1 != 0) {
					adjtable[i1][j1][1] = true;
				} if (j1 != Ncols) {
					adjtable[i1][j1][2] = true;
				} if (j1 != 0) {
					adjtable[i1][j1][3] = true;
				}
		}
	}

	// filling vcolor and link with default values
	cell source(0,0);
	cell sink(Nrows-1, Ncols-1);

	enum color_t { WHITE, BLACK };
	color_t **vcolor;

	cell **link;
	
	vcolor = new color_t*[Nrows];
	link = new cell*[Nrows];
	
	for (int i = 0; i < Nrows; i++) {
		vcolor[i] = new color_t[Ncols];
		link[i] = new cell[Ncols];
		for (int j = 0; j < Ncols; j++) {
			vcolor[i][j] = WHITE;
			link[i][j] = cell();
		}
	}

	rewind(fp);
	fscanf(fp,"%s %i %i", buff, &Nrows, &Ncols);

	int p = 0;
	int NS = 0;				// stack size: initially 0
	int NSmax = 100;		// stack capacity: initially 100
	cell *S;				// stack itself: allocate memory
	S = new cell[NSmax];

	//add source to stack S and source to vcolor and link
	S[NS] = source;
	NS++;
	vcolor[source.i][source.j] = BLACK;
	link[source.i][source.j] = source;

	// DFS
	while (NS != 0) {
		// pop the top of the stack
		cell c = S[NS-1];
		S[NS-1] = S[NS];
		NS--;

		if (c.i == sink.i && c.j == sink.j) {
			break;
		}
			// resize function
			if ((NSmax - p) < 10) {
				NSmax = NSmax * 2;
				cell *tmp = new cell[NSmax];
				for (int j = 0; j < p; j++) {
					tmp[j] = S[j];
				}
				delete[] S;
				S = new cell[NSmax];
				
				for (int j = 0; j < p; j++) {
					S[j] = tmp[j];
				}
				delete[] tmp;
				p = 0;
			}

			for (int i = 0; i < Ncols; i++) {		
			// actual dfs aspect
				// if the cell below c is open
				if (c.i != 0 && adjtable[c.i][i][0] == true && vcolor[c.i-1][i] == WHITE) {
				// push the cell and adjust array
					NS++;
					S[NS].i = c.i-1;
					S[NS].j = i;

					vcolor[c.i-1][i] = BLACK;
					link[c.i-1][i] = cell(c.i, c.j);
					p++;
				// if the cell above c is open
				}	else if (adjtable[c.i][i][1] == true && vcolor[c.i+1][i] == WHITE) {
				//push the cell and adjust array
					NS++;
					S[NS].i = c.i+1;
					S[NS].j = i;
	
					link[c.i+1][i] = cell(c.i, c.j);
					vcolor[c.i+1][i] = BLACK;
					p++;
				// if the cell to left of c is open
				} else if (i != 0 && adjtable[c.i][i][2] == true && vcolor[c.i][i-1] == WHITE) {
				//push the cell and adjust array
					NS++;
					S[NS].i = c.i;
					S[NS].j = i-1;
				
					link[c.i][i] = cell(c.i, c.j);
					vcolor[c.i][i-1] = BLACK;
					p++;
				// if the cell to the right of c is open
				} else if (adjtable[c.i][i][3] == true && vcolor[c.i][i+1] == WHITE) {
				//push the cell and adjsut array
					NS++;
					S[NS].i = c.i;
					S[NS].j = i+1;
				
					link[c.i][i+1] = cell(c.i, c.j);
					vcolor[c.i][i+1] = BLACK;
					p++;
				}
			}
	}

	// deallocating link and vcolor arrays
	for (int i = 0; i < Nrows; i++) {
		delete[] link[i];
		delete[] vcolor[i];
	}
	delete[] link;
	delete[] vcolor;

	// writing the new header to path.txt
	fclose(fp);
	FILE *out;
	out = fopen(fname_out, "w");
	if (!out) { 
		printf("Invalid path file passed\n"); exit(0); 
	}

	fprintf(out,"PATH %i %i\n", Nrows, Ncols);
	fprintf(out,"SOURCE %i %i\n", 0, 0);
	fprintf(out,"SINK %i %i\n", Nrows-1, Ncols-1);

	// writes cells from the stack to path.txt
	cell c5 = S[0];
	while (NS != 0) {
		fprintf(out," %i %i\n", c5.i, c5.j);
		c5 = link[c5.i][c5.j];
	}

	// close file
	fclose(out);

	// deallocate memory for stack and 3D adjtable
	for (int i = 0; i < Nrows; i++) {
		for (int j = 0; j < Ncols; j++) {
			delete[] adjtable[i][j];
		}
		delete[] adjtable[i];
	}
	delete[] adjtable;
	
	return 0;
}	
