#include <time.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// Dillon Frankenstein
// Lab 7
// 11/09/2022 - 11/12/2022

class dset {
	struct node {
		node() { rank = 0, parent = -1; }
		int rank;
		int parent;
	};

	public:
		dset(int Nsets);

		int size() { return Nsets; }

		int merge(int, int);
		int find(int);

	private:
		int Nsets;
		node* S;
};

dset::dset(int N) {
	Nsets = N;
	S = new node[N];
	for (int i = 0; i < (int)sizeof(S); i++) {
		S[i] = node();
	}
}

int dset::merge(int i, int j) {
	i = find(i);
	j = find(j);

	if (i != j) {
		node &Si = S[i];
		node &Sj = S[j];

		// merge (union) by rank
		if (Si.rank > Sj.rank)	Sj.parent = i;
		else if (Si.rank < Sj.rank) Si.parent = j;
		else {Sj.parent = i; Si.rank += 1; }

		Nsets -= 1;
	}

	return find(i);
}

int dset::find(int i) {
	if (S[i].parent == -1)
		return i;

	// recursive path compression
	S[i].parent = find(S[i].parent);
	return S[i].parent;
}

// add constructors as needed ( actually need to add these}
struct cell {
	cell() {i = 0, j = 0; }
	cell (int, int);
	int i, j;
};

cell::cell(int p, int h) {
	i = p;
	j = h;
}
struct cell_pair { 
	cell_pair() {c1 = cell(), c2 = cell(); } 
	cell_pair(cell, cell);
	cell c1, c2; 
};

cell_pair::cell_pair(cell y, cell h) {
	c1 = y;
	c2 = h;
}

int main(int argc, char *argv[]) {
	char fname[8];
	int Nrows, Ncols;
	
	// command line arguments 
	if (argc == 4) {
		for (int i = 1; i < argc; i++) {
			if (i == 1) { Nrows = atoi(argv[i]); }
			else if (i == 2) { Ncols = atoi(argv[i]); }
			else if (i == 3) { strcpy(fname, argv[i]); }
		}
	} else {
		printf ("usage: Nrows Ncols maze.txt\n");
		exit(0);
	}

	srand(time(NULL));

	int Ncells = Nrows*Ncols;
	cell_pair adjlist[2*Ncells];
	
	// populates the adjlist (needs to be tested for outside) initialize both of them 
	int index = 0;
	for (int i = 0; i < Nrows; i++) {
		for (int j = 0; j < Ncols; j++) {
			if (i+1 != Nrows) {
				adjlist[index].c1.i = i+1;
				adjlist[index].c1.j = j;
				index++;
			}
			if (j+1 != Ncols) {
				adjlist[index].c2.i = i;
				adjlist[index].c2.j = j+1;
				index++;
			}
			
		}
	}
	
	// randomize content inplace	
	for (int i = 0; i < index; i++) {
		int swap_i = rand() % index;
		cell_pair tmp = adjlist[i];
		adjlist[i] = adjlist[swap_i];
		adjlist[swap_i] = tmp;
	}

	// write MAZE header to file	
	FILE *fp = fopen(fname, "w"); // write only
	fprintf(fp, "MAZE %u %u\n", Nrows, Ncols);
	fflush(fp);

	dset DS(Ncells);

	int k = 0;
	while (1 < DS.size()) {
		// initialize the new cells to be compared
		cell c1 = adjlist[k].c1;
		cell c2 = adjlist[k].c2;
				
		// the two cells belong to different sets, merge and print them
		if (DS.find(c1.i * Ncols + c1.j) != DS.find(c2.i * Ncols + c2.j)) {
			DS.merge(c1.i * Ncols + c1.j, c2.i * Ncols + c2.j);
			fprintf (fp, "  %u   %u    %u   %u\n", c1.i, c1.j, c2.i, c2.j);
		}
		
		k++;
	}

	fclose(fp);
	return 0;
}

