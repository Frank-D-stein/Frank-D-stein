#ifndef __PERSON_H__ 
#define __PERSON_H__

#include <iomanip>
#include <vector>
#include <string>
#include <fstream>

// Lab 9
// Dillon Frankenstein
// 05.12.2022

using namespace std;

enum type_enum { UNKNOWN=0, FACULTY=1,  ASST_PROF=2, ASSOC_PROF=3, FULL_PROF=4,
                 STUDENT=5, FRESHMAN=6, SOPHOMORE=7, JUNIOR=8, SENIOR=9};

// class person DEFINITION -- base class
class person {
	public:
		person(); 
		virtual ~person() { ; }

		// function used by the other classed
		virtual void add_course(string, double)=0; 
		
		string get_name();			// returns the name
		type_enum get_type();		// returns the type
		type_enum get_category();   // returns the category

		bool operator<(const person &); // comparis operator

		friend void operator<<(person *, string); // input operator
	protected:
		virtual void print_courseinfo()=0; // functions used by other classes
		virtual void print_personinfo()=0;

		// variables
		string name;
		type_enum type;
		type_enum category;
};

// class faculty DEFINITION
class faculty : public person {
	public:
		faculty(string, type_enum); // constructor
		void add_course(string, double); // function from person base class

	private:
		void print_personinfo(); // output and course vector
		void print_courseinfo();
		vector<string> courselist;
};

// class student DEFINITION
class student : public person {
	public:
		student(string, type_enum); // constructor
		void add_course(string, double); // function from the person base class

	private:
		void print_personinfo(); // output, GPA, and course vector
		void print_courseinfo();
		vector<string> courselist;
		vector<double> GPA_list;
};
#endif

