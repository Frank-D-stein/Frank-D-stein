#include <stdlib.h>
#include <vector>
#include <iostream>
#include <string>

// Lab 9
// Dillon Frankenstein
// 05.12.2022

using namespace std;

// global list vector used for comparison
vector <string> list { "UNKNOWN", "FACULTY", "ASST_PROF", "ASSOC_PROF", "FULL_PROF",
					  "STUDENT", "FRESHMAN", "SOPHOMORE", "JUNIOR", "SENIOR" };

#include "Person.h"
#include "Sptrsort.h"

int main(int argc, char *argv[]) {
	string option, mode;

	// command line parsing
	if (argc == 1) {
		cout << "usage: ./Data_processor -person|faculty|student < file.xml\n";
		return 0;
	} else { // hardcoded the mode
		option = argv[1];
		if (option.compare("-person") == 0) {
			mode = "person";
		} else if (option.compare("-student") == 0) {
			mode = "student";
		} else if (option.compare("-faculty") == 0) {
			mode = "faculty";
		}
	}

	// object pointer and vector of object pointers
	person *n_person;
	vector<person *> person_list;

	// type and subtype
	type_enum type = UNKNOWN;
	type_enum g = UNKNOWN;

	// variables 
	int line = 1;
	size_t iL, iR;
	string input, nam, cat, course, gp;
	double GPA;

	// loop that takes data in
	while (getline(cin, input)) {
		++line;

		if ((iL = input.find('<')) == string::npos) {
			continue;

		} else if (input.compare(iL,9,"<faculty>") == 0) {
			type = FACULTY; // passed person is of type faculty

		} else if (input.compare(iL,10,"</faculty>") == 0) {
			continue;
		} else if (input.compare(iL,9,"<student>") == 0) {
			type = STUDENT; // passed person is of type student

		} else if (input.compare(iL,10,"</student>") == 0) {
			continue;

		} else if (input.compare(iL,5,"<name") == 0) {
			iL = input.find("=\"", iL);
			iR = input.find("\"/>", iL+2);

			// extracts the name and puts it into the nam variable
			nam.insert(0, input, iL+2, iR-9);

		} else if (input.compare(iL,10,"<category=") == 0) {
			iL = input.find("=\"", iL);
			iR = input.find("\"/>", iL+2);
	
			// extracts the category from xml file and puts it into cat variable
			cat.insert(0, input, iL+2, iR-13);

			// checks what subtype was actually passedd 
			for (int i = 0; i < (int)list.size(); i++) {
				if (cat == "Assistant Professor") { g = ASST_PROF; }
				if (cat == "Associate Professor") { g = ASSOC_PROF; }
				if (cat == "Professor") { g = FULL_PROF; }
				if (cat == "Freshman") { g = FRESHMAN; }
				if (cat == "Sophomore") { g = SOPHOMORE; }
				if (cat == "Junior") { g = JUNIOR; }
				if (cat == "Senior") { g = SENIOR; }
			}

			// creates the actual objects and adds them to the vector
			if (type == FACULTY) { 
				n_person = new faculty(nam, g);
				person_list.push_back(n_person);
			}
			if (type == STUDENT) {
				n_person = new student(nam, g);
				person_list.push_back(n_person);
			}
			// variable reset
			nam.clear();
			cat.clear();
		
		} else if (input.compare(iL,7,"<course") == 0) {
			iL = input.find("=\"", iL);
			iR = input.find("\"", iL+2);
		
			// extracts the courses from xml file
			course.insert(0, input, iL+2, iR-11);
				
			iL = iR;
			if (type == FACULTY) {
				iR = input.find("/>", iL+1);
				n_person->add_course(course, 0); // just adds courses to course_list
			} else if (type == STUDENT) {
				iL = input.find("gp=\"", iL);
				iR = input.find("\"/>", iL+2);
			
				// adds course and GPA to course vector and GPA vector
				gp.insert(0, input, iL+4, iR-iL-4);
				GPA = stod(gp);
				n_person->add_course(course, GPA);
				// clear gp val
				gp.clear();
			}	
		}
	// clear courses
	course.clear();
	}
	
	// sorts the vector using the sptrsort function from the sptr class
	sptrsort(person_list);
	string useless = "Math"; // useless value used to get to the << operator

	// prints everything out if the mode is person
	if (mode ==  "person") {
		for (int i = 0; i < (int)person_list.size(); i++) {
			person_list[i] << useless;// print out using << operator 
			cout << "\n";
		}
	// prints just the faculty out if the mode is facaulty
	} else if (mode == "faculty") {
		for (int i = 0; i < (int)person_list.size(); i++) {
			if (person_list[i]->get_type() == FACULTY) {
				person_list[i] << useless;
				cout << "\n";
			}
		}
	// prints just the students out if the mode if student
	} else if (mode == "student") {
		for (int i = 0; i < (int)person_list.size(); i++) {
			if (person_list[i]->get_type() == STUDENT) {
				person_list[i] << useless;
				cout << "\n";
			}
		}
	}
	// end.
	return 0;
}
