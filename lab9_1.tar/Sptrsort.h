#include <algorithm>
#include <vector>

// Lab 9
// Dillon Frankenstein
// 05.12.2022

using namespace std;

// sptr class taken from the handout
template <typename T>
class sptr {
	public:
		sptr(T *_ptr=NULL) { ptr = _ptr; }

		bool const operator<(const sptr &rhs) { return *ptr < *rhs.ptr; }

		operator T * () const { return ptr; }
	private:
		T *ptr;
};

// sort function used
template <typename T>
void sptrsort(vector<T *> &A) {
	vector<sptr<person>> B;
	for (int i = 0; i < (int)A.size(); i++) {
		B.push_back(A[i]);
	}
	
	sort (B.begin(), B.end());
	for (int i = 0; i < (int)B.size(); i++) {
		A[i] = B[i];
	}
}
