#include <string>
#include <algorithm>
#include <vector>
#include <iomanip>
#include <iostream>

// Lab 9
// Dillon Frankenstein
// 05.12.2022

using namespace std;

// global vector used to print out the persons type
vector <string> list1 {"UNKOWN","FACULTY", "Assistant Professor", 
	"Associate Professor", "Full Professor", "STUDENT", "Freshman",
	"Sophomore", "Junior", "Senior"};

#include "Person.h"

// PERSON
//-------------------------------------------------------------------
// comparison operator
bool person::operator<(const person &p) {
	if (type == FACULTY && p.type == FACULTY) { // in case faculty is being compared
		if (category == p.category) {			// they are sorted alphabetically
			return name < p.name;
		} else {
			return category < p.category; 
		}
	} else if (type == FACULTY && p.type != FACULTY) { // regular condition
		return true;
	} else if (type != FACULTY && p.type == FACULTY) { // regular condition
		return false;	
	} else if (type == STUDENT && p.type == STUDENT) { // in case students are 
		if (category == p.category) {				   // compared
			return name < p.name;					   // they are sorted 
		} else {									   // alphabetically
			return category < p.category;
		}
	}
	else { return false; }
}
// default
person::person() {
	type = UNKNOWN;
	name = "NULL";
	category = UNKNOWN;
}
// get name
string person::get_name() {
	return name;
}
// get type
type_enum person::get_type() {
	return type;
}
// get category
type_enum person::get_category() {
	return category;
}
// input operator
void operator<<(person *p, string useless) {	
	p->print_personinfo();
	p->print_courseinfo();
}

//FACULTY
//------------------------------------------------------------------
// default
faculty::faculty(string nem, type_enum ok) {
	name = nem;
	category = ok;
	type = FACULTY;
}	
// adds course to course vector
void faculty::add_course(string course, double useless) {
	courselist.push_back(course);
}
// print person info properly formatted
void faculty::print_personinfo() {
	cout << setw(12) << right << " Name: " << name << '\n'
		 << "  Category: " << list1[category] << '\n';
}
// prints the actual course info properly formatted
void faculty::print_courseinfo() {
	sort(courselist.begin(), courselist.end());
	for (int i = 0; i < (int)courselist.size(); i++) {
		cout << setw(12) << right << "Course: " 
			 << setw(24) << left << courselist[i] << '\n';
	}
}

//STUDENT
//-------------------------------------------------------------------
// default
student::student(string nem, type_enum ok) {
	name = nem;
	category = ok;
	type = STUDENT;
}
// adds courses and GPA to both vectors
void student::add_course(string course, double GPA) {
	GPA_list.push_back(GPA);
	courselist.push_back(course);
}
// prints person info properly
void student::print_personinfo() {
	cout << setw(12) << right << " Name: " << name << '\n'
		 << "  Category: " << list1[category] << '\n';
}
// prints the actual course info properly formatted
void student::print_courseinfo() {
	sort(courselist.begin(), courselist.end()); // sorts the couses
	double total = 0;							// running total
	for (int i = 0; i < (int)courselist.size(); i++) {
		total += GPA_list[i];
		cout <<	setw(12) << right << "Course: " << left << setw(24) 
			 << courselist[i] << setprecision(2) << fixed 
			 << "	" << GPA_list[i] <<	" " << total/(i+1) << '\n';
	}
}

